goog.require('Zlib.CRC32');

goog.exportSymbol('Zlib.CRC32', Zlib.CRC32);
goog.exportSymbol('Zlib.CRC32.calc', Zlib.CRC32.calc);
goog.exportSymbol('Zlib.CRC32.update', Zlib.CRC32.update);